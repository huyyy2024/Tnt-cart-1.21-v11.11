package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook vào sendMovementPackets() — học từ BOOST-FPS beforeSync pattern.
 *
 * Lý do quan trọng cho anti-cheat:
 * Grim/Vulcan kiểm tra action packet phải đến CÙNG TICK với movement packet.
 * Nếu interactBlock gửi đi mà không có movement packet kèm theo → flag ngay.
 *
 * Bằng cách trigger placement ngay TRƯỚC khi sendMovementPackets chạy,
 * đảm bảo interact packet và movement packet luôn đến server cùng lúc.
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        FireBowRuntime.get().beforeSync();
    }
}
